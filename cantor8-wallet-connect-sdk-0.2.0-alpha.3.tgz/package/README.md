
# C8 Wallet Connect SDK

Lightweight SDK for dApp developers to integrate the C8 Wallet via a popup window and postMessage communication.

Quick start


## Configuration

You can configure the provider construction:

```
const c8 = new C8WalletProvider({
    dappUrl: window.location.href,
    dappName: "Cantor8 Wallet Connect SDK Demo",
    network: "devnet"
});
```

Sign up for events:

``` 
c8.on('connected', (e) => console.log('Connected', e));
c8.on('disconnected', (e) => console.log('Disconnected', e));
c8.on('accountChanged', (e) => console.log('account's balance changed', e));
c8.on('txInitiated', (e) => console.log('TX initiated', e));
c8.on('txChanged', (e) => console.log('TX changed', e));
```
    
Basic usage

```
 const c8 = new C8WalletProvider({
    dappUrl: window.location.href,
    dappName: "Cantor8 Wallet Connect SDK Demo",
    network: "devnet"
});

await c8.connect();

// Instruments list type: InstrumentListPayload
const instruments = await c8.getInstruments();
console.log('Instruments', instruments);

const firstInstrumentId = instruments.instruments[0]?.instrumentId;

// Accounts list type: AccountListPayload
const accounts = await wallet.getAccounts(firstInstrumentId);
console.log('Accounts', accounts);

const senderPartyId = accounts.accounts[0]?.partyId;
const senderHoldingInstrumentId = accounts.accounts[0]?.holdings[0]?.instrumentId || firstInstrumentId;

// Submit a transfer
// SubmitTransferResultPayload
const res = await c8.send({
    senderPartyId,
    instrumentId: senderHoldingInstrumentId,
    amount: 1.23,
    receiverPartyId: 'Party::Receiver',
});
console.log('Send result', res); // { txId }
```
## API Reference

#### Public API (Provider)

|  | 
| :-------- | 
| `connect(): Promise<void>` | 
| `disconnect(): Promise<void>` | 
| `status(): Promise<{connected: boolean, walletVersion?: string}>` | 
| `getInstruments(): Promise<InstrumentListPayload>` | 
| `getAccounts(instrumentId?: string):  Promise<AccountListPayload>` | 
| `send(input: {senderPartyId: string, instrumentId: string, amount: number, receiverPartyId: string, memo?: string, metadata?: Record<string, string>}): Promise<SubmitTransferResultPayload>` | 
| `checkTxStatusById(input: {partyId: string, txId: string}): Promise<TransferStatusResponsePayload>` | 

#### Events

|  | 
| :-------- | 
| `connected` |
| `disconnected` | 
| `accountChanged` |
| `txInitiated` | 
| `txChanged` | 



